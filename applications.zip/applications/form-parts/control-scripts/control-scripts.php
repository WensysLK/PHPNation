

<!------------------------ Hight Calculation ----------------->
<script src="form-parts/control-scripts/js-scripts/hight-calculation.js"></script>

<!------------------------ date of birth calculation registration form ----------------------->
<script src="form-parts/control-scripts/js-scripts/age-calculation.js"></script>

<!------------------------ Profile Image Handling ----------------------->
<script src="form-parts/control-scripts/js-scripts/profile-picture-settings.js"></script>

<!------------------------ Family Handling ----------------------->
<script src="form-parts/control-scripts/js-scripts/add-family-repeater.js"></script>

<!------------------------ SKills Handling 
<script src="form-parts/control-scripts/js-scripts/skills-details.js"></script>
----------------------->
<!------------------------ License Handling 
<script src="form-parts/control-scripts/js-scripts/license-details.js"></script>
----------------------->
<!------------------------ Language Handling ----------------------->
<script src="form-parts/control-scripts/js-scripts/language-details.js"></script>

<!------------------------ Education Handling ----------------------->
<script src="form-parts/control-scripts/js-scripts/education-details.js"></script>


<!------------------------ Professional Qualification Handling ----------------------->
<script src="form-parts/control-scripts/js-scripts/professional-qualification.js"></script>


<!------------------------ Work Experiance Handling ----------------------->
<script src="form-parts/control-scripts/js-scripts/work-experiance.js"></script>

<!------------------------ Personal Information Handling ----------------------->
<script src="form-parts/control-scripts/js-scripts/select-subagent.js"></script>

