<div > <!-- class="wslk_fam" -->
    <hr>
    <h4>Guardian Details</h4>
    <div class="row">
        <div class="col p-2">
            <label class="form-label ">Guardian's Name</label>
            <input type="text" class="form-control" name="guardianName" id="">
        </div>
        <div class="col p-2">
            <label class="form-label ">Contact Number</label>
            <input type="text" class="form-control" name="guardianContact" id="">
        </div>
        <div class="col p-2">
            <label class="form-label ">Relationship</label>
            <select name="guardianRelationship" class="form-control" id="exampleFormControlSelect1">
                <option selected Value="none">Select Relationship</option>
                <option Value="spouce">Spouce</option>
                <option Value="son">Son</option>
                <option Value="daughter">Daughter</option>
                <option Value="mother">Mother</option>
                <option Vlaue="father">Father</option>
                <option Vlaue="brother">Brother</option>
                <option Vlaue="sister">Sister</option>
            </select>
        </div>
        <div class="col p-2">
            <label class="form-label ">Date of Birth</label>
            <input type="date" class="form-control" name="guardiandob" id="">
        </div>

    </div>
    <div class="row">
        <div class="col p-2">
            <label class="form-label ">National ID</label>
            <input type="text" class="form-control" name="guardianNIC" id="">
        </div>
        <div class="col p-2">
            <label class="form-label ">NIC Front Copy</label>
            <input type="file" class="form-control" name="guardiannicfront" id="">
        </div>
        <div class="col p-2">
            <label class="form-label ">NIC Back Copy</label>
            <input type="file" class="form-control" name="guardiannicback" id="">
        </div>
        <div class="col p-2">
            <label class="form-label ">Family Background Letter</label>
            <input type="file" class="form-control" name="guardianletter" id="">
        </div>
    </div>
</div>